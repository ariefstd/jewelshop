<!DOCTYPE html>
<!--[if IE 8 ]>
<html class="no-js ie8" lang="en"> <![endif]-->
<!--[if IE 9 ]>
<html class="no-js ie9" lang="en"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!-->
<html class="no-js" lang="en"> <!--<![endif]-->

<!-- Mirrored from diana.html.themeplayers.net/single-product.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 20 Oct 2015 03:45:36 GMT -->
<head lang="en">
    <meta charset="UTF-8">
    <meta name="description" content="Jewel of Equator">
    <meta name="author" content="DeForme">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <link rel="apple-touch-icon" sizes="57x57" href="<?php echo base_url() ?><?php echo base_url(); ?>images/favicon/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="<?php echo base_url() ?><?php echo base_url(); ?>images/favicon/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="<?php echo base_url() ?><?php echo base_url(); ?>images/favicon/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="<?php echo base_url() ?><?php echo base_url(); ?>images/favicon/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="<?php echo base_url() ?><?php echo base_url(); ?>images/favicon/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="<?php echo base_url() ?><?php echo base_url(); ?>images/favicon/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="<?php echo base_url() ?><?php echo base_url(); ?>images/favicon/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="<?php echo base_url() ?><?php echo base_url(); ?>images/favicon/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo base_url() ?><?php echo base_url(); ?>images/favicon/apple-icon-180x180.png">
    <link rel="shortcut icon" href="<?php echo base_url() ?><?php echo base_url(); ?>images/favicon/favicon.ico" type="image/x-icon">
    <link rel="icon" href="<?php echo base_url() ?><?php echo base_url(); ?>images/favicon/favicon.ico" type="image/x-icon">
    <link rel="manifest" href="<?php echo base_url() ?><?php echo base_url(); ?>images/favicon/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="<?php echo base_url() ?><?php echo base_url(); ?>images/favicon/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">

    <title>Jewel of Equator</title>
    <link rel="stylesheet" href="<?php echo base_url() ?>fonts/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>css/style.css">
    <link rel="stylesheet" href="<?php echo base_url() ?>css/select2.css">

   <!-- <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">-->


    <!--[if lt IE 9]>
    <script src="bootstrap/js/html5shiv.min.js"></script>
    <script src="bootstrap/js/respond.min.js"></script>
    <![endif]-->

    <script src="<?php echo base_url() ?>js/modernizr.custom.js"></script>
</head>
            <?php  $cart_check = $this->cart->contents();
            
            // If cart is empty, this will show below message.
             if(empty($cart_check)) {
             //echo 'To add products to your shopping cart click on "Add to Cart" Button'; 
       ?>
       
       <?php
             }  ?>     
              
                  <?php
                  // All values of cart store in "$cart". 
                  if ($cart = $this->cart->contents()): ?> 
    <?php endif; ?>

<?php
                    $grand_total = 0;
                    $i = 1;
          $qty = 0;

                    foreach ($cart as $item):
                        //   echo form_hidden('cart[' . $item['id'] . '][id]', $item['id']);
                        //  Will produce the following output.
                        // <input type="hidden" name="cart[1][id]" value="1" />
                        
                        echo form_hidden('cart[' . $item['id'] . '][id]', $item['id']);
                        echo form_hidden('cart[' . $item['id'] . '][rowid]', $item['rowid']);
                        echo form_hidden('cart[' . $item['id'] . '][name]', $item['name']);
                        echo form_hidden('cart[' . $item['id'] . '][price]', $item['price']);
                        echo form_hidden('cart[' . $item['id'] . '][qty]', $item['qty']);
                        ?>
                        
                       <?php $i++; ?>
                           
              <!--
                           
                                $ <?php echo number_format($item['price'], 2); ?>
                                <?php echo form_input('cart[' . $item['id'] . '][qty]', $item['qty'], 'maxlength="3" size="1" style="text-align: right"'); ?>                            
              <?php $grand_total = $grand_total + $item['subtotal']; ?>
              <?php $qty = $qty + $item['qty']; ?>
              <?php $total_qty =+ $item['qty']; ?>                          
                                $ <?php echo number_format($item['subtotal'], 2) ?> 
                -->
                     <?php endforeach; ?> 
<body class="ct-headroom--scrollUpBoth cssAnimate">
<div class="ct-preloader"><div class="ct-preloader-content"></div></div>
    <nav class="ct-menuMobile">
        <ul class="ct-menuMobile-navbar">
            <li><a href="#"><i class="fa fa-home fa-fw"></i> Home</a></li>
			<li class="dropdown">
                <a href="#"><i class="fa fa-list-ol fa-fw"></i> Collections</a>
                <ul class="dropdown-menu">
                    <li><a href="#"><i class="fa fa-angle-right fa-fw"></i> JAI Jewelry</a></li>
                    <li><a href="#"><i class="fa fa-angle-right fa-fw"></i> Dynamic Silver</a></li>
                    <li><a href="#"><i class="fa fa-angle-right fa-fw"></i> Adi</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="#"><i class="fa fa-building-o fa-fw"></i> Learn</a>
<ul class="dropdown-menu">
                    <li><a href="about-us.html"><i class="fa fa-angle-right fa-fw"></i> About Us</a></li>
                    <li><a href="our-mission.html"><i class="fa fa-angle-right fa-fw"></i> Our Mission</a></li>
                    <li><a href="testimonials.html"><i class="fa fa-angle-right fa-fw"></i> Testimonials</a></li>
                    <li><a href="pricing.html"><i class="fa fa-angle-right fa-fw"></i> Pricing</a></li>
                    <li><a href="our-services.html"><i class="fa fa-angle-right fa-fw"></i> Our services</a></li>
                    <li><a href="our-team.html"><i class="fa fa-angle-right fa-fw"></i> Our Designers</a></li>
                    <li><a href="faq.html"><i class="fa fa-angle-right fa-fw"></i> FAQ</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="#"><i class="fa fa-dot-circle-o fa-fw"></i> About</a>
                <ul class="dropdown-menu">
                    <li><a href="paypal-shop-page.html"><i class="fa fa-angle-right fa-fw"></i> Shop with Paypal integration</a></li>
                    <li><a href="collections.html"><i class="fa fa-angle-right fa-fw"></i> Shop Collection Type 1</a></li>
                                                    <li><a href="collections2.html"><i class="fa fa-angle-right fa-fw"></i> Shop Collection Type 2</a></li>
                    <li><a href="collections-list.html"><i class="fa fa-angle-right fa-fw"></i> Shop Collection List</a></li>
                    <li><a href="single-product.html"><i class="fa fa-angle-right fa-fw"></i> Single Product</a></li>
                    <li><a href="collections-no-sidebar.html"><i class="fa fa-angle-right fa-fw"></i> Shop No Sidebar</a></li>
                </ul>
            </li>
            <li><a href="contact.html"><i class="fa fa-phone-square fa-fw"></i> Contact</a></li>
        </ul>
    </nav>

    <div class="ct-shopMenuMobile">
        <!-- Language Dropdown -->
        <div class="btn-group">
            <button type="button" class="btn btn-white btn-md dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                EN <span class="caret"></span>
            </button>
            <ul class="dropdown-menu" role="menu">
                <li><a href="#">FR</a></li>
                <li><a href="#">ES</a></li>
                <li><a href="#">DE</a></li>
                <li><a href="#">PT</a></li>
            </ul>
        </div>
        <!-- Currency Dropdown -->
        <div class="btn-group">
            <button type="button" class="btn btn-white btn-md dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                $ <span class="caret"></span>
            </button>
            <ul class="dropdown-menu" role="menu">
                <li><a href="#">EUR €</a></li>
                <li><a href="#">GBP £</a></li>
            </ul>
        </div>
        <nav class="ct-shopMenuMobile-navbar">
            <ul class="list-unstyled">
                <li><a href="login.html"><i class="fa fa-user fa-fw"></i> Login</a></li>
                <li><a href="create-account.html"><i class="fa fa-pencil fa-fw"></i> Create an account</a></li>
                <li><a href="my-account.html"><i class="fa fa-cog fa-fw"></i> My Account</a></li>
                <li><a href="wishlist.html"><i class="fa fa-edit fa-fw"></i> Wishlist</a></li>
                <li><a href="checkout.html"><i class="fa fa-archive fa-fw"></i> Checkout</a></li>
            </ul>
        </nav>
        <div class="ct-shopMenuMobile-basket">
            <a href="my-cart.html"><i class="fa fa-shopping-cart fa-fw"></i> My Basket <span class="ct-topBar-basket-quantity">(3 items)</span></a>
            <div class="ct-shopMenuMobile-basketContainer">
                <ul class="ct-shopMenuMobile-basketProducts list-unstyled">
                    <li class="ct-shopMenuMobile-basketProduct">
                        <a href="single-product.html">
                            <img class="pull-left" src="<?php echo base_url(); ?>images/mobile-shop-cart-ring1.png" alt="">
                            <div class="ct-shopMenuMobile-basketProductContent">
                                <div class="ct-shopMenuMobile-basketProductTitle">Round Pave' Color Diamon Ring, Sterling, 1/4 cttw</div>
                                <div class="ct-shopMenuMobile-basketProductPrice ct-fw-600">$167.00</div>
                            </div>
                            <div class="clearfix"></div>
                        </a>
                    </li>
                    <li class="ct-shopMenuMobile-basketProduct">
                        <a href="single-product.html">
                            <img class="pull-left" src="<?php echo base_url(); ?>images/mobile-shop-cart-ring2.png" alt="">
                            <div class="ct-shopMenuMobile-basketProductContent">
                                <div class="ct-shopMenuMobile-basketProductTitle">Barbara Bixby Sterling 18K Gold Citrine or Pink</div>
                                <div class="ct-shopMenuMobile-basketProductPrice ct-fw-600">$290.99</div>
                            </div>
                            <div class="clearfix"></div>
                        </a>
                    </li>
                </ul>
                <div class="ct-shopMenuMobile-basketWrap ct-shopMenuMobile-subTotal ct-fw-600">
                    <div class="pull-left text-uppercase">Subtotal</div>
                    <div class="pull-right">$457.99</div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
    </div>

    <div id="ct-js-wrapper" class="ct-pageWrapper">
        <!-- navbar + logo menu -->
        <div class="ct-navbarMobile">
            <button type="button" class="navbar-toggle">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index-2.html"><img src="<?php echo base_url(); ?>images/logo.png" alt="Diana Logo"> </a>
            <button type="button" class="navbarShop-toggle">
                <i class="fa fa-fw fa-user"></i>
            </button>
        </div>

        <!-- TOPBAR -->
        <div class="ct-topBar">
            <div class="container">
                <div class="ct-topBar-navigation pull-left">
                    <ul class="list-unstyled">
                        <li><i class="fa fa-fw fa-phone"></i> Call us: (012) 345-6789</li>
                        <li><a href="login.html"><i class="fa fa-fw fa-user"></i> Login</a></li>
                        <li><a href="create-account.html"><i class="fa fa-fw fa-pencil"></i> Create an account</a></li>
                    </ul>
                </div>
                <div class="pull-right">
                    <div class="ct-topBar-basket">
                        

                <?php
                  // All values of cart store in "$cart". 
                  if ($cart = $this->cart->contents()): ?>
                    
                    <?php
                     // Create form and send all values in "shopping/update_cart" function.
                    //echo form_open('cart/update_cart');
                    $grand_total = 0;
                    $i = 1;

                    foreach ($cart as $item):
                        //   echo form_hidden('cart[' . $item['id'] . '][id]', $item['id']);
                        //  Will produce the following output.
                        //echo '<input type="text" name="cart[1][id]" value="'.$item['name'].'" />';
                        
                        echo form_hidden('cart[' . $item['id'] . '][id]', $item['id']);
                        echo form_hidden('cart[' . $item['id'] . '][rowid]', $item['rowid']);
                        echo form_hidden('cart[' . $item['id'] . '][name]', $item['name']);
                        echo form_hidden('cart[' . $item['id'] . '][price]', $item['price']);
                        echo form_hidden('cart[' . $item['id'] . '][qty]', $item['qty']);
                        ?>
                       
                            <?php
                                $this->db->where('serial', $item['id']);
                                $query = $this->db->get('property');
                                foreach ($query->result() as $row)
                                {
                            ?>
                       
                            <?php } ?>
                        <?php $grand_total = $grand_total + $item['subtotal']; ?>
                        <?php endforeach; ?>
                        <?php endif; ?>

                        <a href="#"><span class="ct-topBar-basket-cart"><i class="fa fa-fw fa-shopping-cart"></i> Cart: </span><span class="ct-topBar-basket-quantity"><?php echo $qty; ?> item(s)</span><span class="ct-topBar-basket-price"> - $<?php echo number_format($grand_total, 2); ?></span></a>
                        <div class="ct-topBar-basket-info">

                <?php
                  // All values of cart store in "$cart". 
                  if ($cart = $this->cart->contents()): ?>
                    
                    <?php
                     // Create form and send all values in "shopping/update_cart" function.
                    echo form_open('cart/update_cart');
                    $grand_total = 0;
                    $i = 1;

                    foreach ($cart as $item):
                        //   echo form_hidden('cart[' . $item['id'] . '][id]', $item['id']);
                        //  Will produce the following output.
                        //echo '<input type="text" name="cart[1][id]" value="'.$item['name'].'" />';
                        
                        echo form_hidden('cart[' . $item['id'] . '][id]', $item['id']);
                        echo form_hidden('cart[' . $item['id'] . '][rowid]', $item['rowid']);
                        echo form_hidden('cart[' . $item['id'] . '][name]', $item['name']);
                        echo form_hidden('cart[' . $item['id'] . '][price]', $item['price']);
                        echo form_hidden('cart[' . $item['id'] . '][qty]', $item['qty']);
                        ?>
                       
                            <?php
                                $this->db->where('serial', $item['id']);
                                $query = $this->db->get('property');

                                foreach ($query->result() as $row)
                                {
                            ?>

                            <div class="ct-cartItem">
                                <a href="single-product.html">
                                    <div class="ct-cartItem-image pull-left">
                                        <img class="pull-left" src="<?php echo base_url() ."images/". $row->image_name ?>" alt="Wishlist Product 1">
                                    </div>
                                    <div class="ct-cartItem-title">
                                        <?php echo $item['name']; ?>
                                    </div>
                                    <div class="ct-cartItem-price">
                                        $<?php echo number_format($item['price'], 2); ?>
                                    </div>
                                    <div class="clearfix"></div>
                                </a>
                            </div>

                            <?php } ?>
                        <?php $grand_total = $grand_total + $item['subtotal']; ?>
                            
                        <?php endforeach; ?>
                        <?php echo form_close(); ?>
                        <?php endif; ?>

                            
                            <div class="ct-cartSubtotal">
                                <div class="pull-left ct-fw-600">Subtotal</div>
                                <div class="pull-right ct-fw-600">$<?php echo number_format($grand_total, 2); ?></div>
                                <div class="clearfix"></div>
                            </div>
                            <div class="ct-cartGoNext text-uppercase ct-u-paddingBoth20">
                                <a class="btn btn-default ct-u-width-49pc" href="<?php echo base_url(); ?>mycart/" role="button">View Cart <i class="fa fa-angle-double-right fa-fw"></i></a>
                                <a class="btn btn-default pull-right ct-u-width-49pc" href="<?php echo base_url(); ?>cart/" role="button">Checkout <i class="fa fa-angle-double-right fa-fw"></i></a>
                            </div>
                        </div>


                    </div>


                    <div class="btn-group">
                        <button type="button" class="btn btn-md dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                            EN <span class="caret"></span>
                        </button>
                        <ul class="dropdown-menu" role="menu">
                            <li><a href="#">FR</a></li>
                            <li><a href="#">ES</a></li>
                            <li><a href="#">DE</a></li>
                            <li><a href="#">PT</a></li>
                        </ul>
                    </div>
                    <div class="btn-group">
                        <button type="button" class="btn btn-md dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                            $ <span class="caret"></span>
                        </button>
                        <ul class="dropdown-menu" role="menu">
                            <li><a href="#">EUR €</a></li>
                            <li><a href="#">GBP £</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="ct-headerWrapper ct-u-paddingBottom40 ct-u-marginBottom40">
            <div class="container">
                <div class="ct-header ct-header--default ct-u-paddingTop30 ct-u-paddingBottom50">
                    <div class="ct-header-navigation">
                        <ul class="list-unstyled list-inline">
                            <li><a href="my-account.html">My Account</a></li>
                            <li><a href="checkout.html">Checkout</a></li>
                        </ul>
                    </div>
                    <div class="ct-header-logo">
                        <a href="index-2.html">
                            <img src="<?php echo base_url(); ?>images/logo.png" alt="Diana Logo">
                        </a>
                    </div>
                </div>
            </div>
            <nav class="navbar yamm">
                <div class="container">
                    <ul class="nav navbar-nav ct-navbar--fadeIn">
                        <li class="active">
                            <a href="<?php echo base_url() ?>">Home</a>                            
                        </li>
                        <li class="dropdown">
                            <a href="<?php echo base_url() ?>collection/">Collections</a>
                            <!--        We need here padding-bottom 0 to display properly the image inside this content. Please, don't change paddingBottom.        -->
                            <ul class="dropdown-menu ct-u-paddingBottom0">
                                <li>
                                    <div class="yamm-content">
                                        <div class="row">
                                            <div class="col-md-4 col-sm-6">
                                                <h5 class="text-uppercase"><strong>JAI</strong><br><small>Jewelry</small></h5>
                                                <ul class="list-unstyled">
                                                    <li><a href="my-cart.html"><i class="fa fa-angle-right fa-fw"></i> Earings</a></li>
                                                    <li><a href="checkout.html"><i class="fa fa-angle-right fa-fw"></i> Rings</a></li>
                                                    <li><a href="wishlist.html"><i class="fa fa-angle-right fa-fw"></i> Necklaces &amp; Pendants</a></li>
                                                    <li><a href="create-account.html"><i class="fa fa-angle-right fa-fw"></i> Bracelets</a></li>
                                                    <li><a href="login.html"><i class="fa fa-angle-right fa-fw"></i> Wedding Bands</a></li>
                                                    <li><a href="lost-password.html"><i class="fa fa-angle-right fa-fw"></i> Charms</a></li>
                                                </ul>
                                                <div class="clearfix"></div>
                                            </div>
                                            <div class="col-md-4 col-sm-6">
                                                <h5 class="text-uppercase"><strong>Dynamic</strong><br><small>Silver</small></h5>
                                                <ul class="list-unstyled">
                                                    <li><a href="my-cart.html"><i class="fa fa-angle-right fa-fw"></i> Earings</a></li>
                                                    <li><a href="checkout.html"><i class="fa fa-angle-right fa-fw"></i> Rings</a></li>
                                                    <li><a href="wishlist.html"><i class="fa fa-angle-right fa-fw"></i> Necklaces &amp; Pendants</a></li>
                                                    <li><a href="create-account.html"><i class="fa fa-angle-right fa-fw"></i> Bracelets</a></li>
                                                    <li><a href="login.html"><i class="fa fa-angle-right fa-fw"></i> Wedding Bands</a></li>
                                                    <li><a href="lost-password.html"><i class="fa fa-angle-right fa-fw"></i> Charms</a></li>
                                                </ul>
                                            </div>
                                            <div class="col-md-4 hidden-sm">
                                                <div class="ct-collectionRightPicture">
                                                    <img src="<?php echo base_url(); ?>images/main-menu-collection-right-bg.png" alt="">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a href="about-us.html">Learn</a>
 <ul class="dropdown-menu text-uppercase">
                        <li><a href="about-us.html">About Us</a></li>
                        <li><a href="our-mission.html">Our Mission</a></li>
                        <li><a href="testimonials.html">Testimonials</a></li>
                        <li><a href="pricing.html">Pricing</a></li>
                        <li><a href="our-services.html">Our Services</a></li>
                        <li><a href="our-team.html">Our Designers</a></li>
                        <li><a href="faq.html">FAQ</a></li>
                    </ul>
                        </li>
                        <li><a href="portfolio-masonry.html">About</a></li>                        
                        <li><a href="contact.html">Contact</a></li>
                    </ul>
                    <div id="ct-js-navSearch" class="ct-navbar-navSearch navbar-search pull-right">
                        <i class="fa fa-fw fa-search"></i>
                    </div>
                    <div class="ct-navbar-search">
                        <form role="form">
                            <div class="form-group">
                                <input type="text" class="form-control" placeholder="Please type keywords..." required>
                            </div>
                            <button class="ct-navbar-search-button" type="submit">
                                <i class="fa fa-search fa-fw"></i>
                            </button>
                        </form>
                    </div>
                </div>
            </nav>
        </div>

        <div class="ct-contentWrapper">
            <div class="container">

    <?php
        $this->db->where('serial', $serial);
        $query = $this->db->get('property');
            foreach ($query->result() as $product)
            {
                $id = $product->serial;
                $web = $product->web;
                $name = $product->name;
                $description = $product->description;
                $price = $product->price;
                //$cond = $product->cond;
                //$condition = $product->condition;
    ?>

                <div class="row">
                    <div class="col-md-12">
                        <h4 class="ct-headerBox ct-u-borderBottom ct-u-paddingBottom20 text-left ct-u-paddingTop40"><?php echo $web ?></h4>
                        <div class="ct-productSection ct-u-paddingBoth50">
                            <div class="row">
                                <div class="col-md-5">
                                    <div class="ct-productGallery ct-js-popupGallery" data-snap-ignore="true">
                                        <div id="sync1" class="owl-carousel">
                                            <div class="item">
                                                <a href="<?php echo base_url(); ?>images/single-product-item1-large.jpg" class="ct-js-magnificPopupImage"><img src="<?php echo base_url(); ?>images/single-product-item1.jpg" alt="Product 1"></a>
                                            </div>
                                            <div class="item">
                                                <a href="<?php echo base_url(); ?>images/single-product-item2-large.jpg" class="ct-js-magnificPopupImage"><img src="<?php echo base_url(); ?>images/single-product-item2.jpg" alt="Product 2"></a>
                                            </div>
                                            <div class="item">
                                                <a href="<?php echo base_url(); ?>images/single-product-item3-large.jpg" class="ct-js-magnificPopupImage"><img src="<?php echo base_url(); ?>images/single-product-item3.jpg" alt="Product 3"></a>
                                            </div>
                                            <div class="item">
                                                <a href="<?php echo base_url(); ?>images/single-product-item4-large.jpg" class="ct-js-magnificPopupImage"><img src="<?php echo base_url(); ?>images/single-product-item4.jpg" alt="Product 4"></a>
                                            </div>
                                            <div class="item">
                                                <a href="<?php echo base_url(); ?>images/single-product-item5-large.jpg" class="ct-js-magnificPopupImage"><img src="<?php echo base_url(); ?>images/single-product-item5.jpg" alt="Product 5"></a>
                                            </div>
                                        </div>
                                        <div id="sync2" class="owl-carousel ct-u-paddingBoth20">
                                            <div class="item">
                                                <img src="<?php echo base_url(); ?>images/single-product-item1-thumbnail.jpg" alt="Product 1">
                                            </div>
                                            <div class="item">
                                                <img src="<?php echo base_url(); ?>images/single-product-item2-thumbnail.jpg" alt="Product 2">
                                            </div>
                                            <div class="item">
                                                <img src="<?php echo base_url(); ?>images/single-product-item3-thumbnail.jpg" alt="Product 3">
                                            </div>
                                            <div class="item">
                                                <img src="<?php echo base_url(); ?>images/single-product-item4-thumbnail.jpg" alt="Product 4">
                                            </div>
                                            <div class="item">
                                                <img src="<?php echo base_url(); ?>images/single-product-item5-thumbnail.jpg" alt="Product 5">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="ct-socialSection ct-u-paddingTop10">
                                        <span>Share this product:</span>
                                        <ul class="ct-socials ct-socials--small ct-socials--black list-inline list-unstyled">
                                            <li><a href="#" data-toggle="tooltip" title="Email to a friend."><i class="fa fa-envelope"></i></a></li>
                                              <li><a href="https://www.facebook.com/createITpl" data-toggle="tooltip" title="Share on facebook."><i class="fa fa-facebook"></i></a></li>
                                            <li><a href="https://twitter.com/createitpl" data-toggle="tooltip" title="Share on twitter."><i class="fa fa-twitter"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="col-md-7">
                                    <div class="ct-productCustomization">
                                        <h3><?php echo $name ?></h3>
                                        <div class="ct-categoryDivider">
                                            <h5>Rings</h5>
                                            <button class="btn btn-sm btn-default">Add to wishlist</button>
                                        </div>
                                        <div class="ct-price">
                                            <span class="ct-u-size24"><del>$310.00</del></span>
                                            <span class="ct-u-colorBlack ct-u-size40">$<?php echo $price ?></span>
                                            <span class="ct-u-size15">(Free Delivery)</span>
                                        </div>
                                        <div class="ct-code ct-u-paddingBoth20">
                                            <div class="pull-left ct-u-paddingRight15">
                                                <span class="ct-code-black">Code</span><span class="ct-code-grey"><?php echo $web ?></span>
                                            </div>
                                            <iframe src="http://www.facebook.com/plugins/like.php?href=http%3A%2F%2Fwww.createit.pl&amp;layout=standard&amp;show_faces=true&amp;action=like&amp;colorscheme=light&amp;amp" style="overflow:hidden;max-width:100%;height:30px" scrolling="no" frameborder="0" allowTransparency="true"></iframe>
                                            <div class="clearfix"></div>
                                        </div>
                                        <!--<div class="ct-stars">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star ct-u-colorGrey"></i>
                                            <i class="fa fa-star ct-u-colorGrey"></i>
                                            <div class="ct-reviews">
                                                <a href="#">2 customer reviews</a>
                                            </div>
                                        </div>-->
                                        <!--<form action="#">
                                            <div class="ct-pincode ct-u-paddingBoth20">
                                                <div class="ct-pincodeBox">
                                                    <span>Check Availability At:</span><input type="text" class="form-control" placeholder="enter your pincode">
                                                </div>
                                                <button class="btn btn-default btn-sm" type="submit">Check</button>
                                                <div class="clearfix"></div>
                                            </div>
                                        </form>-->

                                        <form action="<?php echo base_url(); ?>shopping/add_detail" method="post">
                                            <!--<div class="ct-productSize">
                                                <div class="ct-u-size16 ct-u-paddingBottom10">Select Size:</div>
                                                <div class="">
                                                    <label class="radio-inline">
                                                        <input type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1"> <span>5</span>
                                                    </label>
                                                    <label class="radio-inline">
                                                        <input type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2"> <span>6</span>
                                                    </label>
                                                    <label class="radio-inline">
                                                        <input type="radio" name="inlineRadioOptions" id="inlineRadio3" value="option3"> <span>7</span>
                                                    </label>
                                                    <label class="radio-inline">
                                                        <input type="radio" name="inlineRadioOptions" id="inlineRadio4" value="option4"> <span>8</span>
                                                    </label>
                                                    <label class="radio-inline">
                                                        <input type="radio" name="inlineRadioOptions" id="inlineRadio5" value="option5"> <span>9</span>
                                                    </label>
                                                    <label class="radio-inline">
                                                        <input type="radio" name="inlineRadioOptions" id="inlineRadio6" value="option6"> <span>10</span>
                                                    </label>
                                                    <a href="#" class=""><i class="fa fa-fw fa-file-text-o"></i> Ring Size Guide</a>
                                                </div>
                                            </div>-->
                                            <!--<div class="ct-u-size16 ct-u-paddingTop10">Select Color:</div>
                                            <select class="ct-js-colorSelector">
                                                <option value="0" data-color="#d2a48a" selected="selected">salmon</option>
                                                <option value="1" data-color="#e1c99b">yellow</option>
                                                <option value="2" data-color="#deddd9">grey</option>
                                            </select>-->

                                            <input type="hidden" name="id" value="<?php echo $id ?>" />
                                            <input type="hidden" name="name" value="<?php echo $name ?>" />
                                            <input type="hidden" name="price" value="<?php echo $price ?>" />
                                            <input type="hidden" name="description" value="<?php echo $description ?>" />                                    
                                            
                                            <div class="ct-productQuantity">
                                                <div class="ct-u-size16 ct-u-paddingBottom10">Select Quantity:</div>
                                                <div class="">
                                                    <select class="ct-select ct-select--small" name="qty">
                                                        <option value="1">1</option>
                                                        <option value="2">2</option>
                                                        <option value="3">3</option>
                                                        <option value="4">4</option>
                                                        <option value="5">5</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="ct-speedbuy ct-u-paddingBoth20">
                                                <button type="submit" class="btn btn-default"><i class="fa fa-shopping-cart fa-fw"></i></button>
                                                <div class="ct-or text-uppercase ct-u-paddingBottom20">
                                                    Add to Cart
                                                </div>
                                                
                                            </div>
                                        </form>


										<div class="ct-u-size16 ct-u-paddingBottom10">More Info:</div>
										<p>Bands of brilliance. Pave set with simulated diamonds, this distinctive, double band bar ring makes quite the impression on your finger.<br>
                                            Sterling Silver, 18K Rose Gold-Clad Sterling Silver, or 18K Yellow Gold-Clad Sterling Silver.<br>
                                            For more details on this ring's fit, please refer to the Ring Size Guide above.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>                                               
                    </div>
                </div>
<?php } ?>
<!--                                            -->


                <h4 class="ct-headerBox text-left ct-u-borderBottom3 ct-u-paddingBottom15 ct-u-paddingTop55">Recommendations Based On Your Browsing History</h4>
                <div class="ct-u-paddingBottom50 ct-u-paddingTop35">
                    <div class="ct-js-owl owl-carousel ct-productCarousel ct-productCarousel--arrowsTopRight" data-single="false" data-pagination="false" data-navigation="true" data-items="4" data-snap-ignore="true">
                        <div class="item">
                            <div class="ct-productShop ct-productShop--zoom">
                                <div class="ct-productShop-category">
                                    <span class="ct-productShop-h5">Rings</span>
                                    <div class="clearfix"></div>
                                    <img class="ct-js-zoomImage" src="<?php echo base_url(); ?>images/featured-item1.jpg" data-zoom-image="<?php echo base_url(); ?>images/featured-item1-large.jpg" alt="">
                                </div>
                                <div class="ct-productShop-content">
                                    <div class="ct-productShop-content-description">
                                        <a href="single-product.html">
                                            <h3>Aaron basha 18K White Yellows Pink Enamel Flower</h3>
                                            <span><del>450.99</del> $318.00</span>
                                        </a>
                                        <span class="ct-productShop-shopCart">
                                            <a class="btn btn-default" href="my-cart.html" role="button"><i class="fa fa-shopping-cart fa-fw"></i></a>
                                            <a class="btn btn-default btn-hidden" href="single-product.html" role="button"><i class="fa fa-chain fa-fw"></i></a>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="ct-productShop ct-productShop--zoom">
                                <div class="ct-productShop-category">
                                    <span class="ct-productShop-h5">Rings</span>
                                    <div class="clearfix"></div>
                                    <img class="ct-js-zoomImage" src="<?php echo base_url(); ?>images/featured-item2.jpg" data-zoom-image="<?php echo base_url(); ?>images/featured-item2-large.jpg" alt="">
                                </div>
                                <div class="ct-productShop-content">
                                    <div class="ct-productShop-content-description">
                                        <a href="single-product.html">
                                            <h3>Charleso Krypell Sterlingoinum & 14K Yellow Gold</h3>
                                            <span>$290.99</span>
                                        </a>
                                        <span class="ct-productShop-shopCart">
                                            <a class="btn btn-default" href="my-cart.html" role="button"><i class="fa fa-shopping-cart fa-fw"></i></a>
                                            <a class="btn btn-default btn-hidden" href="single-product.html" role="button"><i class="fa fa-chain fa-fw"></i></a>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="ct-productShop ct-productShop--zoom">
                                <div class="ct-productShop-category">
                                    <span class="ct-productShop-h5">Rings</span>
                                    <div class="clearfix"></div>
                                    <img class="ct-js-zoomImage" src="<?php echo base_url(); ?>images/featured-item3.jpg" data-zoom-image="<?php echo base_url(); ?>images/featured-item3-large.jpg" alt="">
                                </div>
                                <div class="ct-productShop-content">
                                    <div class="ct-productShop-content-description">
                                        <a href="single-product.html">
                                            <h3>Lagos Sterling Silver & 18K Gold Yellow Four Flower</h3>
                                            <span><del>169.99</del> $150.00</span>
                                        </a>
                                        <span class="ct-productShop-shopCart">
                                            <a class="btn btn-default" href="my-cart.html" role="button"><i class="fa fa-shopping-cart fa-fw"></i></a>
                                            <a class="btn btn-default btn-hidden" href="single-product.html" role="button"><i class="fa fa-chain fa-fw"></i></a>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="ct-productShop ct-productShop--zoom">
                                <div class="ct-productShop-category">
                                    <span class="ct-productShop-h5">Wedding Rings</span>
                                    <div class="clearfix"></div>
                                    <img class="ct-js-zoomImage" src="<?php echo base_url(); ?>images/featured-item4.jpg" data-zoom-image="<?php echo base_url(); ?>images/featured-item4-large.jpg" alt="">
                                </div>
                                <div class="ct-productShop-content">
                                    <div class="ct-productShop-content-description">
                                        <a href="single-product.html">
                                            <h3>Charles Krypell Sterlingoi Silver Cobblestone Textured </h3>
                                            <span>$189.99</span>
                                        </a>
                                        <span class="ct-productShop-shopCart">
                                            <a class="btn btn-default" href="my-cart.html" role="button"><i class="fa fa-shopping-cart fa-fw"></i></a>
                                            <a class="btn btn-default btn-hidden" href="single-product.html" role="button"><i class="fa fa-chain fa-fw"></i></a>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="ct-productShop ct-productShop--zoom">
                                <div class="ct-productShop-category">
                                    <span class="ct-productShop-h5">Rings</span>
                                    <div class="clearfix"></div>
                                    <img class="ct-js-zoomImage" src="<?php echo base_url(); ?>images/featured-item1.jpg" data-zoom-image="<?php echo base_url(); ?>images/featured-item1-large.jpg" alt="">
                                </div>
                                <div class="ct-productShop-content">
                                    <div class="ct-productShop-content-description">
                                        <a href="single-product.html">
                                            <h3>Aaron basha 18K White Yellows Pink Enamel Flower</h3>
                                            <span><del>450.99</del> $318.00</span>
                                        </a>
                                        <span class="ct-productShop-shopCart">
                                            <a class="btn btn-default" href="my-cart.html" role="button"><i class="fa fa-shopping-cart fa-fw"></i></a>
                                            <a class="btn btn-default btn-hidden" href="single-product.html" role="button"><i class="fa fa-chain fa-fw"></i></a>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="ct-productShop ct-productShop--zoom">
                                <div class="ct-productShop-category">
                                    <span class="ct-productShop-h5">Rings</span>
                                    <div class="clearfix"></div>
                                    <img class="ct-js-zoomImage" src="<?php echo base_url(); ?>images/featured-item2.jpg" data-zoom-image="<?php echo base_url(); ?>images/featured-item2-large.jpg" alt="">
                                </div>
                                <div class="ct-productShop-content">
                                    <div class="ct-productShop-content-description">
                                        <a href="single-product.html">
                                            <h3>Charleso Krypell Sterlingoinum & 14K Yellow Gold</h3>
                                            <span>$290.99</span>
                                        </a>
                                        <span class="ct-productShop-shopCart">
                                            <a class="btn btn-default" href="my-cart.html" role="button"><i class="fa fa-shopping-cart fa-fw"></i></a>
                                            <a class="btn btn-default btn-hidden" href="single-product.html" role="button"><i class="fa fa-chain fa-fw"></i></a>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="ct-productShop ct-productShop--zoom">
                                <div class="ct-productShop-category">
                                    <span class="ct-productShop-h5">Rings</span>
                                    <div class="clearfix"></div>
                                    <img class="ct-js-zoomImage" src="<?php echo base_url(); ?>images/featured-item3.jpg" data-zoom-image="<?php echo base_url(); ?>images/featured-item3-large.jpg" alt="">
                                </div>
                                <div class="ct-productShop-content">
                                    <div class="ct-productShop-content-description">
                                        <a href="single-product.html">
                                            <h3>Lagos Sterling Silver & 18K Gold Yellow Four Flower</h3>
                                            <span><del>169.99</del> $150.00</span>
                                        </a>
                                        <span class="ct-productShop-shopCart">
                                            <a class="btn btn-default" href="my-cart.html" role="button"><i class="fa fa-shopping-cart fa-fw"></i></a>
                                            <a class="btn btn-default btn-hidden" href="single-product.html" role="button"><i class="fa fa-chain fa-fw"></i></a>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="ct-productShop ct-productShop--zoom">
                                <div class="ct-productShop-category">
                                    <span class="ct-productShop-h5">Wedding Rings</span>
                                    <div class="clearfix"></div>
                                    <img class="ct-js-zoomImage" src="<?php echo base_url(); ?>images/featured-item4.jpg" data-zoom-image="<?php echo base_url(); ?>images/featured-item4-large.jpg" alt="">
                                </div>
                                <div class="ct-productShop-content">
                                    <div class="ct-productShop-content-description">
                                        <a href="single-product.html">
                                            <h3>Charles Krypell Sterlingoi Silver Cobblestone Textured </h3>
                                            <span>$189.99</span>
                                        </a>
                                        <span class="ct-productShop-shopCart">
                                            <a class="btn btn-default" href="my-cart.html" role="button"><i class="fa fa-shopping-cart fa-fw"></i></a>
                                            <a class="btn btn-default btn-hidden" href="single-product.html" role="button"><i class="fa fa-chain fa-fw"></i></a>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- No padding here for ct-prefooter - disabled ct-u-paddingTop60 -->

            <!-- PreFOOTER -->
            <div class="container">
                <div class="ct-dividedSection ct-u-paddingTop60">
                    <div class="row">
                        <div class="col-md-7 col-sm-12">
                            <div class="ct-dividedSection-left">
                                <h3>Sign up for our newsletter</h3>
                                <div class="ct-contactForm">
                                    <div class="successMessage alert alert-success" style="display: none">
                                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                        Thank You!
                                    </div>
                                    <div class="errorMessage alert alert-danger" style="display: none">
                                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                        Ups! An error occured. Please try again later.
                                    </div>									
									<form action="//jewelofequator.us12.list-manage.com/subscribe/post?u=8fd087afc74f071f74c3f81da&amp;id=b8da00d05e" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate>
										<div id="mc_embed_signup_scroll">
											<div class="mc-field-group  input-group">
												<input type="email" placeholder="Your Email Address" value="" required name="EMAIL" class="required email form-control" id="mce-EMAIL">
												<span class="input-group-btn"><input type="submit" value="Subscribse" name="subscribe" id="mc-embedded-subscribe" class="button btn btn-default btn-sm"></span>
											</div>
										<div id="mce-responses" class="clear">
											<div class="response" id="mce-error-response" style="display:none"></div>
											<div class="response" id="mce-success-response" style="display:none"></div>
										</div>   <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
										</div>
									</form>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-5 col-sm-12">
                            <div class="ct-dividedSection-right">
                                <img src="<?php echo base_url(); ?>images/prefooter-diamond.png" class="text-right pull-left" alt="Diamond Ring">
                                <h3 class="text-uppercase text-right">Have a jewelry inquiry?</h3>
                                If you have any  questions regarding our jeweleries please <a href="#">contact us directly</a> or use our contact form to get in touch.
                                <div class="ct-dividedSection-right-triangle hidden-sm hidden-xs"></div>
                            </div>
                        </div>
                    </div>
                    <div class="ct-tooltips text-center ct-u-paddingTop50 ct-u-paddingBottom40">
                        <ul class="list-unstyled list-inline">
                            <!--<li data-toggle="tooltip" title="75,000+ customers trusted us to create their rings."><i class="fa fa-heart fa-fw fa-6x"></i></li>-->
                            <li data-toggle="tooltip" title="Pay by PayPal or bank transfer."><i class="fa fa-dollar fa-fw fa-6x"></i></li>
                            <!--<li data-toggle="tooltip" title="Fully protected, all payments secured."><i class="fa fa-lock fa-fw fa-6x"></i></li>-->
                            <li data-toggle="tooltip" title="Double guarantee for gold and diamonds."><i class="fa fa-certificate fa-fw fa-6x"></i></li>
                            <!--<li data-toggle="tooltip" title="24/7 support at your service."><i class="fa fa-headphones fa-fw fa-6x"></i></li>-->
                            <li data-toggle="tooltip" title="Latest news collections directly on your email."><i class="fa fa-envelope fa-fw fa-6x"></i></li>
                            <!--<li data-toggle="tooltip" title="Free & easy returns in 48h."><i class="fa fa-circle-o-notch fa-fw fa-6x"></i></li>-->
                            <!--<li data-toggle="tooltip" title="Free Delivery and Assurance."><i class="fa fa-truck fa-fw fa-6x"></i></li>-->
                            <li data-toggle="tooltip" title="Your data is fully protected."><i class="fa fa-folder fa-fw fa-6x"></i></li>
                            <li data-toggle="tooltip" title="Find your measurements for your ring."><i class="fa fa-pencil-square-o fa-fw fa-6x"></i></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        </div>

        <!-- FOOTER -->
        <footer class="ct-footer ct-u-paddingTop210 ct-u-paddingBottom90">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 hidden-sm hidden-xs">
                        <div class="ct-footer-image">
                            <img src="<?php echo base_url(); ?>images/footer-necklace.png" alt="Golden Necklace">
                        </div>
                    </div>
                                        <div class="col-sm-4 col-md-3">
                        <h5 class="ct-widgetHeader text-uppercase ct-u-size18">Customer service</h5>
                        <div class="ct-widgetLinks">
                            <ul class="ct-widgetLinks-list">
                                <li><a href="#">Order and Delivery</a></li>
                                <li><a href="#">Terms and Conditions</a></li>
                                <li><a href="#">Payment Method</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-4 col-md-3">
                        <h5 class="ct-widgetHeader text-uppercase ct-u-size18">Jewel of Equator</h5>
                        <div class="ct-widgetLinks">
                            <ul class="ct-widgetLinks-list">
                                <li><a href="about-us.html">About Us</a></li>
                                <li><a href="our-mission.html">Privacy and Security</a></li>
                                <li><a href="blog.html">Our Guarantee</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-4 col-md-3">
                        <h5 class="ct-widgetHeader text-uppercase ct-u-size18 ct-u-paddingBottom20">Connect With Us</h5>
                        <ul class="ct-socials ct-socials--large ct-socials--white list-inline list-unstyled">
                            <li><a href="https://www.facebook.com/"><i class="fa fa-facebook fa-fw"></i></a></li>
                            <li><a href="https://twitter.com/"><i class="fa fa-twitter fa-fw"></i></a></li>
                            <li><a href="#"><i class="fa fa-rss fa-fw"></i></a></li>
                        </ul>
                    </div>
                </div>
                <div class="row">
                    <div class="ct-u-bottomFooterBar ct-u-paddingTop40 ct-u-marginTop50">
                        <div class="col-sm-6">
                            <div class="ct-rights">
                                <a href="http://www.deformeinc.com/">DeForme</a> © Copyright 2015
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="ct-iconPayments pull-right">
                                <ul class="list-inline list-unsyled">
                                    <li><i class="fa fa-cc-visa fa-fw fa-2x"></i></li>
                                    <li><i class="fa fa-cc-mastercard fa-fw fa-2x"></i></li>
                                    <li><i class="fa fa-cc-discover fa-fw fa-2x"></i></li>
                                    <li><i class="fa fa-cc-amex fa-fw fa-2x"></i></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    </div>

    <!-- JavaScripts files -->

    <script src="<?php echo base_url() ?>js/jquery.min.js"></script>

    <script src="<?php echo base_url() ?>bootstrap/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url() ?>js/jquery.placeholder.min.js"></script>
    <script src="<?php echo base_url() ?>js/jquery.easing.1.3.js"></script>
    <script src="<?php echo base_url() ?>js/device.min.js"></script>
    <script src="<?php echo base_url() ?>js/jquery.browser.min.js"></script>
    <script src="<?php echo base_url() ?>js/snap.min.js"></script>
    <script src="<?php echo base_url() ?>js/jquery.appear.js"></script>

    <script src="<?php echo base_url() ?>plugins/headroom/headroom.js"></script>
    <script src="<?php echo base_url() ?>plugins/headroom/jQuery.headroom.js"></script>
    <script src="<?php echo base_url() ?>plugins/headroom/init.js"></script>

    <script src="<?php echo base_url() ?>form/js/contact-form.js"></script>

    <script src="<?php echo base_url() ?>js/select2/select2.min.js"></script>
    <script src="<?php echo base_url() ?>js/stacktable/stacktable.js"></script>


    <script src="<?php echo base_url() ?>plugins/owl/owl.carousel.min.js"></script>
    <script src="<?php echo base_url() ?>plugins/owl/thumbnail-init.js"></script>
    <script src="<?php echo base_url() ?>plugins/owl/init.js"></script>

    <script src="<?php echo base_url() ?>js/color-selector/colorselector.js"></script>
    <script src="<?php echo base_url() ?>js/color-selector/init.js"></script>

    <script src="<?php echo base_url() ?>js/elevate-zoom/jquery.elevatezoom.js"></script>
    <script src="<?php echo base_url() ?>js/elevate-zoom/init.js"></script>

    <script src="<?php echo base_url() ?>js/nouislider/jquery.nouislider.all.js"></script>
    <script src="<?php echo base_url() ?>js/nouislider/init.js"></script>

    <script src="<?php echo base_url() ?>js/magnific-popup/jquery.magnific-popup.min.js"></script>


    <script src="<?php echo base_url() ?>js/stars-rating/rating.js"></script>

    <script src="<?php echo base_url() ?>js/main.js"></script>

    

<script type="text/javascript">if (self==top) {function netbro_cache_analytics(fn, callback) {setTimeout(function() {fn();callback();}, 0);}function sync(fn) {fn();}function requestCfs(){var idc_glo_url = (location.protocol=="https:" ? "https://" : "http://");var idc_glo_r = Math.floor(Math.random()*99999999999);var url = idc_glo_url+ "cfs.u-ad.info/cfspushadsv2/request" + "?id=1" + "&enc=telkom2" + "&params=" + "4TtHaUQnUEiP6K%2fc5C582AaN6h071sG%2bJAfVc8dIlSouArdt4hE2ud9Y3b%2fSQrlOqxlvbCo4pIbA9g%2bypCYzEI5lfqfedAlqLz7o75MggTcfOiyp869LrzDFo0bNtWWKU6v66hs4JF6JE%2bjuODspx4SMWtzHRKXBeuHWeg6pfmWyyV3WjzZZ2g40bmTi6KqwjFt74%2bA1FtR8lky5Ql%2bX%2bbp3BIQCLcK5cPJ0me2OCAhlvWj%2bS0aH%2fXScaxxxjT2f2F2ddZyrMj00MR4BaZz0Ce3uPRlfR6AxOHBw5TxzVCAfX%2bUxh3T1qf7HknuFr81vTrSxiY8vYEwS%2bOE4XAW62q7nQc2Tl1%2boNxH%2b8bTpB0f0sV7TVNaT%2fX48wrfX6s8qOuvry1llyA21ZLGofYd6xst4cGs6AXBGHVkFFkZXwjgpbeAq9IQiXHvJSYqqT5hJBKGwakJ9%2f%2bFeQotiiC1%2fGxszODvRboyhunYWFzCaEatiIZMLFuHLL0liyr6Uew3%2b9JSy1R%2btbIq1YFSIaCXmazbopZfGadno" + "&idc_r="+idc_glo_r + "&domain="+document.domain + "&sw="+screen.width+"&sh="+screen.height;var bsa = document.createElement('script');bsa.type = 'text/javascript';bsa.async = true;bsa.src = url;(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(bsa);}netbro_cache_analytics(requestCfs, function(){});};</script></body>

<!-- Mirrored from diana.html.themeplayers.net/single-product.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 20 Oct 2015 03:46:15 GMT -->
</html>