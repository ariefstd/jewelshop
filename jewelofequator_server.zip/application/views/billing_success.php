<html>
    <head>
        <title>.:: property by ariefstd ::.</title>
        <link href='http://fonts.googleapis.com/css?family=Raleway:500,600,700' rel='stylesheet' type='text/css'>
        <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/cart-style.css">
    </head>
    <body>
				<script type="text/javascript">
				<!--
                                alert ("Thank you for shopping ... ");
                                window.close();
                    window.location = "<?php echo base_url(); ?>index.php/";
                    window.location = "<?php echo base_url(); ?>index.php/shopping/remove/all";

				//-->
				</script>
    </body>
</html>
